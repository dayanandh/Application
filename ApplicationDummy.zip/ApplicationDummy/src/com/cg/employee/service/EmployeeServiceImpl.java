package com.cg.employee.service;

import java.util.ArrayList;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{
	EmployeeDao dao;
	
	public EmployeeServiceImpl()
	{
		dao = new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.addEmployee(emp);
	}

	@Override
	public Employee removeEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.removeEmployee(empId);
	}

	@Override
	public Employee getEmployeeById(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployeeById(empId);
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getAllEmployee();
	}

	@Override
	public Employee updateEmployee(int empId, int empSal)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.updateEmployee(empId, empSal);
	}

}




